import React, { useState } from "react";
import "../styles/calculator.css";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import "jspdf-autotable";

export default function Calculator() {
  const [items, setItems] = useState([{ name: "", qty: 0, price: 0 }]);
  const [giftBoxCost, setGiftBoxCost] = useState(0);
  const [packagingCost, setPackagingCost] = useState(0);
  const [logisticsCost, setLogisticsCost] = useState(0);
  const [overheads, setOverheads] = useState(0);
  const [gst, setGst] = useState(5);
  const [profitMargin, setProfitMargin] = useState(0);

  // 🔹 Calculations
  const calculateSubtotal = () =>
    items.reduce((sum, i) => sum + i.qty * i.price, 0) +
    Number(giftBoxCost) +
    Number(packagingCost) +
    Number(logisticsCost) +
    Number(overheads);

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    return subtotal + (subtotal * gst) / 100;
  };

  const calculateSellingPrice = () => {
    const total = calculateTotal();
    return total + (total * profitMargin) / 100;
  };

  // 🔹 Item handling
  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    newItems[index][field] = value;
    setItems(newItems);
  };

  const addItem = () => {
    setItems([...items, { name: "", qty: 0, price: 0 }]);
  };

  const removeItem = (index) => {
    const newItems = items.filter((_, i) => i !== index);
    setItems(newItems);
  };

  // 🔹 Export Functions
  const exportToCSV = () => {
    let csv = "Item,Qty,Unit Price,Subtotal\n";
    items.forEach((i) => {
      csv += `${i.name},${i.qty},${i.price},${i.qty * i.price}\n`;
    });
    csv += `\nGift Box Cost,${giftBoxCost}\nPackaging Cost,${packagingCost}\nLogistics Cost,${logisticsCost}\nOverheads,${overheads}\n`;
    csv += `Subtotal,${calculateSubtotal()}\nGST (${gst}%),${
      (calculateSubtotal() * gst) / 100
    }\nTotal,${calculateTotal()}\nProfit Margin (${profitMargin}%),${
      (calculateTotal() * profitMargin) / 100
    }\nSelling Price,${calculateSellingPrice()}\n`;

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "gift_box_calculation.csv");
    link.click();
  };

  const exportToExcel = () => {
    const data = [
      ["Item", "Qty", "Unit Price", "Subtotal"],
      ...items.map((i) => [i.name, i.qty, i.price, i.qty * i.price]),
      [],
      ["Gift Box Cost", giftBoxCost],
      ["Packaging Cost", packagingCost],
      ["Logistics Cost", logisticsCost],
      ["Overheads", overheads],
      [],
      ["Subtotal", calculateSubtotal()],
      [`GST (${gst}%)`, (calculateSubtotal() * gst) / 100],
      ["Total", calculateTotal()],
      [`Profit Margin (${profitMargin}%)`, (calculateTotal() * profitMargin) / 100],
      ["Selling Price", calculateSellingPrice()],
    ];

    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Gift Box Calculator");
    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    saveAs(new Blob([wbout], { type: "application/octet-stream" }), "gift_box_calculation.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();

    doc.text("Gift Box Cost Calculator", 14, 15);
    doc.autoTable({
      startY: 25,
      head: [["Item", "Qty", "Unit Price", "Subtotal"]],
      body: items.map((i) => [i.name, i.qty, i.price, i.qty * i.price]),
    });

    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 10,
      head: [["Component", "Value"]],
      body: [
        ["Gift Box Cost", giftBoxCost],
        ["Packaging Cost", packagingCost],
        ["Logistics Cost", logisticsCost],
        ["Overheads", overheads],
        ["Subtotal", calculateSubtotal()],
        [`GST (${gst}%)`, (calculateSubtotal() * gst) / 100],
        ["Total", calculateTotal()],
        [`Profit Margin (${profitMargin}%)`, (calculateTotal() * profitMargin) / 100],
        ["Selling Price", calculateSellingPrice()],
      ],
    });

    doc.save("gift_box_calculation.pdf");
  };

  // 🔹 UI
  return (
    <div className="calculator">
      <h1>Gift Box Cost Calculator</h1>

      {/* Items Table */}
      <table className="items-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Unit Price (₹)</th>
            <th>Subtotal (₹)</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {items.map((i, index) => (
            <tr key={index}>
              <td>
                <input
                  type="text"
                  value={i.name}
                  onChange={(e) => handleItemChange(index, "name", e.target.value)}
                  placeholder="Item name"
                />
              </td>
              <td>
                <input
                  type="number"
                  value={i.qty}
                  onChange={(e) =>
                    handleItemChange(index, "qty", Number(e.target.value))
                  }
                />
              </td>
              <td>
                <input
                  type="number"
                  value={i.price}
                  onChange={(e) =>
                    handleItemChange(index, "price", Number(e.target.value))
                  }
                />
              </td>
              <td>{i.qty * i.price}</td>
              <td>
                <button onClick={() => removeItem(index)}>❌</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={addItem}>+ Add Item</button>

      {/* Additional Costs */}
      <div className="extra-costs">
        <label>
          Gift Box Cost:
          <input
            type="number"
            value={giftBoxCost}
            onChange={(e) => setGiftBoxCost(Number(e.target.value))}
          />
        </label>
        <label>
          Packaging Cost:
          <input
            type="number"
            value={packagingCost}
            onChange={(e) => setPackagingCost(Number(e.target.value))}
          />
        </label>
        <label>
          Logistics Cost:
          <input
            type="number"
            value={logisticsCost}
            onChange={(e) => setLogisticsCost(Number(e.target.value))}
          />
        </label>
        <label>
          Overheads:
          <input
            type="number"
            value={overheads}
            onChange={(e) => setOverheads(Number(e.target.value))}
          />
        </label>
      </div>

      {/* GST & Profit */}
      <div className="tax-profit">
        <label>
          GST %:
          <select value={gst} onChange={(e) => setGst(Number(e.target.value))}>
            <option value={5}>5%</option>
            <option value={12}>12%</option>
            <option value={18}>18%</option>
          </select>
        </label>
        <label>
          Profit Margin %:
          <input
            type="number"
            value={profitMargin}
            onChange={(e) => setProfitMargin(Number(e.target.value))}
          />
        </label>
      </div>

      {/* Results */}
      <div className="results">
        <p>Subtotal: ₹{calculateSubtotal()}</p>
        <p>GST Amount: ₹{(calculateSubtotal() * gst) / 100}</p>
        <p>Total Cost: ₹{calculateTotal()}</p>
        <p>Selling Price (with profit): ₹{calculateSellingPrice()}</p>
      </div>

      {/* Export Buttons */}
      <div className="export-buttons">
        <button onClick={exportToCSV}>Export CSV</button>
        <button onClick={exportToExcel}>Export Excel</button>
        <button onClick={exportToPDF}>Export PDF</button>
      </div>
    </div>
  );
}
