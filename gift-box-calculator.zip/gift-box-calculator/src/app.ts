import Calculator from "./components/Calculator";

export default function App() {
  return (
    <div className="App">
      <Calculator />
    </div>
  );
}
